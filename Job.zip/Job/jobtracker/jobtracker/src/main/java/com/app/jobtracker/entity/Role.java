package com.app.jobtracker.entity;

public enum Role {
    APPLICANT,
    ADMIN,
    RECRUITER
}
