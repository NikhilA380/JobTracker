package com.app.jobtracker.service.impl;

import com.app.jobtracker.dto.JobRequestDTO;
import com.app.jobtracker.dto.JobResponseDTO;
import com.app.jobtracker.entity.Job;
import com.app.jobtracker.entity.Role;
import com.app.jobtracker.entity.User;
import com.app.jobtracker.exception.ResourceNotFoundException;
import com.app.jobtracker.repository.JobRepository;
import com.app.jobtracker.repository.UserRepository;
import com.app.jobtracker.service.JobService;
import org.springframework.stereotype.Service;

@Service
public class JobServiceImpl implements JobService {

    private final JobRepository jobRepository;
    private final UserRepository userRepository;

    public JobServiceImpl(JobRepository jobRepository,
                          UserRepository userRepository) {
        this.jobRepository = jobRepository;
        this.userRepository = userRepository;
    }

    @Override
    public JobResponseDTO createJob(JobRequestDTO dto, Long recruiterId) {

        User recruiter = userRepository.findById(recruiterId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Recruiter not found"));

        // BUSINESS RULE
        if (recruiter.getRole() != Role.RECRUITER) {
            throw new IllegalStateException("Only recruiters can post jobs");
        }

        Job job = new Job();
        job.setTitle(dto.getTitle());
        job.setDescription(dto.getDescription());
        job.setLocation(dto.getLocation());
        job.setCompany(dto.getCompany());
        job.setRecruiter(recruiter);

        Job saved = jobRepository.save(job);

        JobResponseDTO response = new JobResponseDTO();
        response.setId(saved.getId());
        response.setTitle(saved.getTitle());
        response.setLocation(saved.getLocation());
        response.setCompany(saved.getCompany());
        response.setRecruiterEmail(recruiter.getEmail());

        return response;
    }
}
