package com.app.jobtracker.entity;

public enum ApplicationStatus {
    APPLIED,
    SHORTLISTED,
    REJECTED
}
