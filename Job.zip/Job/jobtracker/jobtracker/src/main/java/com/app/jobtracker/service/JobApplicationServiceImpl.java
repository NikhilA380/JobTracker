package com.app.jobtracker.service;

import com.app.jobtracker.entity.*;
import com.app.jobtracker.exception.ResourceNotFoundException;
import com.app.jobtracker.repository.JobApplicationRepository;
import com.app.jobtracker.repository.JobRepository;
import com.app.jobtracker.repository.UserRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@AllArgsConstructor
public class JobApplicationServiceImpl implements JobApplicationService{

    private final JobRepository jobRepository;
    private final UserRepository userRepository;
    private final JobApplicationRepository applicationRepository;


    @Override
    public void applyToJob(Long jobId, Long applicantId) {
        User applicant = userRepository.findById(applicantId)
                .orElseThrow(()-> new ResourceNotFoundException("Applicant not found..."));

        if(applicant.getRole() != Role.APPLICANT){
            throw new IllegalStateException("Only Applicant can apply to jobs.");
        }

        Job job = jobRepository.findById(jobId)
                .orElseThrow(()-> new ResourceNotFoundException("Job not found"));

        if (applicationRepository
                .existsByJobIdAndApplicantId(jobId, applicantId)) {
            throw new IllegalStateException("Already applied to this job");
        }

        JobApplication application = new JobApplication();
        application.setApplicant(applicant);
        application.setJob(job);
        application.setAppliedAt(LocalDateTime.now());
        application.setStatus(ApplicationStatus.APPLIED);

        applicationRepository.save(application);
    }
}
