package com.app.jobtracker.service;

import com.app.jobtracker.dto.JobRequestDTO;
import com.app.jobtracker.dto.JobResponseDTO;

public interface JobService {

    JobResponseDTO createJob(JobRequestDTO dto, Long recruiterId);
}
