package com.app.jobtracker.controller;

import com.app.jobtracker.dto.JobRequestDTO;
import com.app.jobtracker.dto.JobResponseDTO;
import com.app.jobtracker.service.JobService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
@RequestMapping("/api/jobs")
public class JobController {

    private final JobService jobService;

    public ResponseEntity<JobResponseDTO> createJob(@PathVariable Long recruiterId, @Valid @RequestBody JobRequestDTO dto){
        return new ResponseEntity<>(
                jobService.createJob(dto, recruiterId),
                HttpStatus.CREATED
        );
    }
}
