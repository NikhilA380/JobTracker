package com.app.jobtracker.service;

public interface JobApplicationService {

    void applyToJob(Long jobId, Long applicantId);
}
