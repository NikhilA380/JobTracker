package com.app.jobtracker.security;

import io.jsonwebtoken.Claims;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;

public class JwtFilter implements Filter {

    @Override
    public void doFilter(
            ServletRequest request,
            ServletResponse response,
            FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        String authHeader = httpRequest.getHeader("Authorization");

        if (authHeader != null && authHeader.startsWith("Bearer ")) {

            String token = authHeader.substring(7);
            Claims claims = JwtUtil.validateToken(token);

            httpRequest.setAttribute("userId",
                    Long.parseLong(claims.getSubject()));
            httpRequest.setAttribute("role",
                    claims.get("role"));
        }

        chain.doFilter(request, response);
    }
}
