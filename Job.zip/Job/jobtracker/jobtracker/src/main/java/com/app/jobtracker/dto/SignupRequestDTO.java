package com.app.jobtracker.dto;

import com.app.jobtracker.entity.Role;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SignupRequestDTO {

    private String name;
    private String email;
    private String password;
    private Role role;

    // getters and setters
}
