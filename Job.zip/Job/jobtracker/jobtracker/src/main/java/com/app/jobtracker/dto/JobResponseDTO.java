package com.app.jobtracker.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class JobResponseDTO {

    private Long id;
    private String title;
    private String location;
    private String company;
    private String recruiterEmail;

    // getters and setters
}
