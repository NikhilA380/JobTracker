package com.app.jobtracker.controller;

import com.app.jobtracker.service.JobApplicationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/jobs")
public class JobApplicationController {

    private final JobApplicationService applicationService;

    public JobApplicationController(JobApplicationService applicationService) {
        this.applicationService = applicationService;
    }

    @PostMapping("/{jobId}/apply")
    public ResponseEntity<String> applyToJob(
            @PathVariable Long jobId,
            @PathVariable Long applicantId) {

        applicationService.applyToJob(jobId, applicantId);
        return ResponseEntity.ok("Applied successfully");
    }
}
