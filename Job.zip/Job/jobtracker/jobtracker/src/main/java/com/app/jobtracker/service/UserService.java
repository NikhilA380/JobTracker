package com.app.jobtracker.service;

import com.app.jobtracker.dto.LoginRequestDTO;
import com.app.jobtracker.dto.SignupRequestDTO;
import com.app.jobtracker.entity.User;

public interface UserService {

    User signup(SignupRequestDTO dto);

    User login(LoginRequestDTO dto);
}
