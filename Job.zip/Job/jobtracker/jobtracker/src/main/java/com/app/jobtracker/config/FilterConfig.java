package com.app.jobtracker.config;

import com.app.jobtracker.security.JwtFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.boot.web.servlet.FilterRegistrationBean;

@Configuration
public class FilterConfig {

    @Bean
    public FilterRegistrationBean<JwtFilter> jwtFilter() {

        FilterRegistrationBean<JwtFilter> bean =
                new FilterRegistrationBean<>();

        bean.setFilter(new JwtFilter());
        bean.addUrlPatterns("/api/jobs/*");

        return bean;
    }
}
