package com.app.jobtracker.controller;

import com.app.jobtracker.dto.LoginRequestDTO;
import com.app.jobtracker.dto.SignupRequestDTO;
import com.app.jobtracker.entity.User;
import com.app.jobtracker.security.JwtUtil;
import com.app.jobtracker.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/signup")
    public ResponseEntity<User> signup(@RequestBody SignupRequestDTO dto) {
        return ResponseEntity.ok(userService.signup(dto));
    }

//    @PostMapping("/login")
//    public ResponseEntity<User> login(@RequestBody LoginRequestDTO dto) {
//        return ResponseEntity.ok(userService.login(dto));
//    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginRequestDTO dto) {

        User user = userService.login(dto);

        String token = JwtUtil.generateToken(
                user.getId(),
                user.getRole().name()
        );

        return ResponseEntity.ok(token);
    }

}
